// Получаем холст и контекст
const canvas = document.getElementById('gameCanvas');
const ctx = canvas.getContext('2d');

// Флаг для управления экранами
let gameStarted = false;

// Функция запуска игры (вызывается из кнопки меню)
function startGame() {
    document.getElementById('mainMenu').style.display = 'none';
    gameStarted = true;
}

// Игровой цикл (сердце игры)
function gameLoop() {
    // Очищаем холст
    ctx.fillStyle = '#3a3a3a';
    ctx.fillRect(0, 0, canvas.width, canvas.height);

    if (gameStarted) {
        // Пока просто напишем, что игра началась
        ctx.fillStyle = 'white';
        ctx.font = '30px Arial';
        ctx.fillText('Идёт игра!', 300, 300);
    }

    requestAnimationFrame(gameLoop); // запускаем следующий кадр
}

// Запускаем цикл сразу после загрузки
gameLoop();