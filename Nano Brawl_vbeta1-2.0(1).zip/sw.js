const CACHE_NAME = 'nano-brawl-v1';
const FILES_TO_CACHE = [
  'NanoBrawl.html',
  'style.css',
  'game_old.js',      // если используется
  'manifest.json',
  'icons/icon-192x192.png',
  'icons/icon-512x512.png'
];

// Установка – кэшируем файлы
self.addEventListener('install', (event) => {
  event.waitUntil(
    caches.open(CACHE_NAME).then((cache) => cache.addAll(FILES_TO_CACHE))
  );
  self.skipWaiting();
});

// Перехват запросов – сначала ищем в кэше, потом в сети
self.addEventListener('fetch', (event) => {
  event.respondWith(
    caches.match(event.request).then((response) => response || fetch(event.request))
  );
});

// Очистка старых кэшей при активации
self.addEventListener('activate', (event) => {
  event.waitUntil(
    caches.keys().then((keyList) => Promise.all(
      keyList.map((key) => {
        if (key !== CACHE_NAME) return caches.delete(key);
      })
    ))
  );
  self.clients.claim();
});